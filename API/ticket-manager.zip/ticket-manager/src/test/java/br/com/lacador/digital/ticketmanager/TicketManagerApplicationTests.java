package br.com.lacador.digital.ticketmanager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TicketManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
